<?php
/**
 *  The template for displaying the front page.
 *
 *  @package WordPress
 *  @subpackage illdy
 */


get_header();


if ( get_option( 'show_on_front' ) == 'posts' ) : ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-7">
				<section id="blog">
					<?php do_action( 'illdy_above_content_after_header' ); ?>
					<?php
					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							get_template_part( 'template-parts/content', get_post_format() );
						endwhile;
					else :
						get_template_part( 'template-parts/content', 'none' );
					endif;
					?>
					<?php do_action( 'illdy_after_content_above_footer' ); ?>
				</section><!--/#blog-->
			</div><!--/.col-sm-7-->
			<?php get_sidebar(); ?>
		</div><!--/.row-->
	</div><!--/.container-->

<?php
else :

	$sections_order_first_section   = get_theme_mod( 'illdy_general_sections_order_first_section', 1 );
	$sections_order_second_section  = get_theme_mod( 'illdy_general_sections_order_second_section', 2 );
	$sections_order_third_section   = get_theme_mod( 'illdy_general_sections_order_third_section', 3 );
	$sections_order_fourth_section  = get_theme_mod( 'illdy_general_sections_order_fourth_section', 4 );
	$sections_order_fifth_section   = get_theme_mod( 'illdy_general_sections_order_fifth_section', 5 );
	$sections_order_sixth_section   = get_theme_mod( 'illdy_general_sections_order_sixth_section', 6 );
	$sections_order_seventh_section = get_theme_mod( 'illdy_general_sections_order_seventh_section', 7 );
	$sections_order_eighth_section  = get_theme_mod( 'illdy_general_sections_order_eighth_section', 8 );

	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			$static_page_content = get_the_content();
			if ( '' != $static_page_content ) :
			?>
				<section class="front-page-section" id="static-page-content">
					<div class="section-header">
						<div class="container">
							<div class="row">
								<div class="col-sm-12">
									<h3><?php the_title(); ?></h3>
								</div><!--/.col-sm-12-->
							</div><!--/.row-->
						</div><!--/.container-->
					</div><!--/.section-header-->
					<div class="section-content">
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-10 col-sm-offset-1">
									<?php echo $static_page_content; ?>
								</div>
							</div>
						</div>
					</div>
				</section>
			<?php endif;
		endwhile;
	endif;

	illdy_sections();

endif;

get_footer(); ?>
