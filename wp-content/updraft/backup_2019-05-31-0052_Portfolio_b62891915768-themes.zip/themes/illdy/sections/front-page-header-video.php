<?php
/* Section Video Header */
?>
<div class="illdy-jumbotron-background">
	<div id="wp-custom-header" class="wp-custom-header"></div>
</div>
